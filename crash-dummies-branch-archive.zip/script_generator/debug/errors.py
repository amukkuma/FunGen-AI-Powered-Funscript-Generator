class FFProbeError(Exception):
    pass

class FFMpegError(Exception):
    pass
